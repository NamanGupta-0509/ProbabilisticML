import os
import sys
import logging

module_path = os.path.abspath(os.path.join("/content/drive/MyDrive/Colab Notebooks/pvi-main"))
if module_path not in sys.path:
    sys.path.append(module_path)
from pvi.models.logistic_regression import LogisticRegressionModel
from pvi.clients import Client
from pvi.utils.gaussian import mvstandard2natural, mvnatural2standard
from pvi.servers.sequential_server import SequentialServer
from pvi.distributions.exponential_family_distributions import MultivariateGaussianDistribution, MeanFieldGaussianDistribution
from pvi.distributions.exponential_family_factors import MultivariateGaussianFactor, MeanFieldGaussianFactor

import torch
import numpy as np
import matplotlib.pyplot as plt
import tqdm.auto as tqdm

from torch import nn
from sklearn.preprocessing import OrdinalEncoder

# Set seed for PyTorch
torch.manual_seed(0)

# Set seed for NumPy
np.random.seed(0)

# %matplotlib inline
torch.set_default_dtype(torch.float64)
N = 128

snr_db1=np.arange(10,11,1)
loop=len(snr_db1)
error_vec=torch.zeros(loop)


# x_o = np.array([-1,1,-1,1]) # creates a numpy array

max_iter=5
for loop_iter in range(loop):
  snr_db=snr_db1[loop_iter]
  noise_var=10**(-snr_db/10)
  for ii in range(max_iter):
    print(ii)
    M = 20 # Number of single antenna users
    x = np.random.randn(N,M) # Channel Matrix
    x = torch.from_numpy(x).double()
    # breakpoint()
    # Create a tensor of size 20x1 with values 0 or 1
    x_o = torch.randint(0, 2, (20,)) # data vector
    # Replace 0 with -1
    x_o[x_o == 0] = -1
    x_o = x_o.double()  # convert x_o to double type
    y_q = x @ x_o.T


    y_q = y_q + np.sqrt(noise_var) * np.random.randn(N)  #received data
    #breakpoint()
    y = np.sign(y_q) # uses numpy sign function
    y[y == -1] = 0 # changes all values of y_q that are -1 to 0
    y = torch.tensor(y, dtype=torch.float32) # convert y to float32
    D = x.shape[1]
    # print(D)
    N = x.shape[0]
    M = 16 # Number of APs
    client_size_factor = 0
    small_client_size = int(np.floor((1 - client_size_factor) * N/M))
    big_client_size = int(np.floor((1 + client_size_factor) * N/M))

    # print(small_client_size)
    # print(big_client_size)


    pos_inds = np.where(y > 0)
    zero_inds = np.where(y == 0)

    y_pos = y[pos_inds]
    y_neg = y[zero_inds]

    x_pos = x[pos_inds]
    x_neg = x[zero_inds]

    x = np.concatenate([x_pos, x_neg])
    y = np.concatenate([y_pos, y_neg])
    shuffle_inds = np.random.permutation(x.shape[0])

    x = x[shuffle_inds]
    y = y[shuffle_inds]

    client_data = []

    for i in range(int(M)):
      client_x = x[:big_client_size]
      client_y = y[:big_client_size]

      x = x[big_client_size:]
      y = y[big_client_size:]

      client_data.append({'x': client_x, 'y': client_y})

    # clients_data = []
    # clients_data.append([x,y])

    clients = []

    # Shared across all clients.
    hyperparameters = {
        "D": D,
        "optimiser": "Adam",
        "optimiser_params": {"lr": 1e-2},
        "epochs": 100,
        "batch_size": 100,
        "num_elbo_samples": 1,
        "num_predictive_samples": 10
    }

    prior_std_params = {
        "loc": torch.zeros(hyperparameters["D"] + 1),
        "scale": torch.ones(hyperparameters["D"] + 1),
    }

    init_nat_params = {
        "np1": torch.zeros(hyperparameters["D"] + 1),
        "np2": torch.zeros(hyperparameters["D"] + 1),
    }

    # Construct clients.
    for i in range(M):
        model_i = LogisticRegressionModel(hyperparameters=hyperparameters)
        data_i = client_data[i]
        t_i = MeanFieldGaussianFactor(nat_params=init_nat_params)

        # # Convert to torch.tensor.
        for key in data_i:
            data_i[key] = torch.tensor(data_i[key])
        client = Client(data=data_i, model=model_i, t=t_i, config=hyperparameters)
        clients.append(client)

    # Construct server.
    model = LogisticRegressionModel(hyperparameters=hyperparameters)
    q = MeanFieldGaussianDistribution(std_params=prior_std_params, is_trainable=False)
    server = SequentialServer(model=model, p=q, clients=clients)
    server.timer.start()
    server._tick()
    #print(server.q.std_params)
    #print(x_o)

    detect_sym = server.q.std_params['loc'][:20]
    demod_sym = torch.where(detect_sym< 0, -1, 1)
    #print(detect_sym)
    #print(x_o)
    #print(demod_sym)
    err_temp=(demod_sym != x_o).sum().item()
    error_vec[loop_iter]=error_vec[loop_iter]+err_temp
error_vec=error_vec/(max_iter*20)
print(error_vec)
print(x_o)
print(demod_sym)
print(detect_sym)