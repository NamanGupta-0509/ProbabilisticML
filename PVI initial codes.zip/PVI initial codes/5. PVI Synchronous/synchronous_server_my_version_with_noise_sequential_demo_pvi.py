import os
import sys
import logging
module_path = os.path.abspath(os.path.join("/content/drive/MyDrive/Colab Notebooks/pvi-main"))
if module_path not in sys.path:
    sys.path.append(module_path)

# Commented out IPython magic to ensure Python compatibility.
from pvi.models.logistic_regression import LogisticRegressionModel
from pvi.clients import Client
from pvi.utils.gaussian import mvstandard2natural, mvnatural2standard
from pvi.servers.sequential_server import SequentialServer
from pvi.servers.synchronous_server import SynchronousServer
from pvi.distributions.exponential_family_distributions import MultivariateGaussianDistribution, MeanFieldGaussianDistribution
from pvi.distributions.exponential_family_factors import MultivariateGaussianFactor, MeanFieldGaussianFactor
import torch
import numpy as np
import matplotlib.pyplot as plt
import tqdm.auto as tqdm
from torch import nn
from sklearn.preprocessing import OrdinalEncoder
# %matplotlib inline
torch.set_default_dtype(torch.float64)

# Set seed for PyTorch
torch.manual_seed(0)

# Set seed for NumPy
np.random.seed(0)

# Set seed for Python's built-in random module
#random.seed(0)
# ------------------------------------------------------------------------------------------------------
# INITIALIZATION

mc_iter = 1000                      # number of monte-carlo iterations
N = 128                           # number of antennas
M = 20                            # number of users
snr = np.arange(10, 31, 10)          # SNR values
snrlen = len(snr)
errorr = np.zeros(snrlen)
count = 0;
# ------------------------------------------------------------------------------------------------------
# PVI Model Begins

for snr_val in snr:               # SNR loop begins
  print('SNR is:', snr_val)
  for ii in range(mc_iter):        # Monte-carlo iteration begins
    print('iteration is:', ii)
    sigma = 10**(-snr_val/10)
    noise = np.sqrt(2*sigma)*np.random.randn(N)
    x_in = np.random.randn(N,M) # calls the randn function with the np.random namespace
    x_in = torch.from_numpy(x_in).double() # Convert to tensor
    # Create a tensor of size (no of users x 1) with values 0 or 1
    x_o = torch.randint(0, 2, (20,))
    x_o[x_o == 0] = -1            # Replace 0 with -1
    x_o = x_o.double()            # convert x_o to double type
    y_q = x_in @ x_o.T + noise    # matrix multiplication of x_in and x_o with noise addition
    y_in = np.sign(y_q)           # uses numpy sign function
    y_in[y_in == -1] = 0          # changes all values of y_q that are -1 to 0
    y_in = torch.tensor(y_in, dtype=torch.float32) # convert y to float32
    D = x_in.shape[1]
    N = x_in.shape[0]
    Cl = 16                  # number of clients for decentralized learning
# -------------------------------------------------------------------------------------------------------
    #  CLIENT DATA GENERATION BEGINS

    client_size_factor = 0
    small_client_size = int(np.floor((1 - client_size_factor) * N/M))
    big_client_size = int(np.floor((1 + client_size_factor) * N/M))
    pos_inds = np.where(y_in > 0)
    zero_inds = np.where(y_in == 0)
    y_pos = y_in[pos_inds]
    y_neg = y_in[zero_inds]
    x_pos = x_in[pos_inds]
    x_neg = x_in[zero_inds]
    x = np.concatenate([x_pos, x_neg])
    y = np.concatenate([y_pos, y_neg])
    shuffle_inds = np.random.permutation(x.shape[0])
    x = x[shuffle_inds]
    y = y[shuffle_inds]
    client_data = []

        # Calculate the data points per client
    data_per_client = len(x) // Cl

    for i in range(Cl):
      # Ensure each client gets at least one data point
      client_x = x[i * data_per_client : (i + 1) * data_per_client]
      client_y = y[i * data_per_client : (i + 1) * data_per_client]
      client_data.append({'x': client_x, 'y': client_y})

    # for i in range(int(Cl)):
    #   client_x = x[:big_client_size]
    #   client_y = y[:big_client_size]
    #   x = x[big_client_size:]
    #   y = y[big_client_size:]
    #   client_data.append({'x': client_x, 'y': client_y})
    clients = []
    # Shared across all clients.
    hyperparameters = {"D": D,
        "optimiser": "Adam",
        "optimiser_params": {"lr": 1e-2},
        "epochs": 100,
        "batch_size": 100,
        "num_elbo_samples": 1,
        "num_predictive_samples": 10}
    prior_std_params = {"loc": torch.zeros(hyperparameters["D"] + 1), "scale": torch.ones(hyperparameters["D"] + 1),}
    init_nat_params = {"np1": torch.zeros(hyperparameters["D"] + 1), "np2": torch.zeros(hyperparameters["D"] + 1),}

    # Construct clients.
    for i in range(Cl):
        model_i = LogisticRegressionModel(hyperparameters=hyperparameters)
        data_i = client_data[i]
        t_i = MeanFieldGaussianFactor(nat_params=init_nat_params)
        # Convert to torch.tensor.
        for key in data_i:
            data_i[key] = torch.tensor(data_i[key])
        client = Client(data=data_i, model=model_i, t=t_i, config=hyperparameters)
        clients.append(client)
# ------------------------------------------------------------------------------------------------------
    # Construct sequential server

    model = LogisticRegressionModel(hyperparameters=hyperparameters)
    q = MeanFieldGaussianDistribution(std_params=prior_std_params, is_trainable=False)
    server = SynchronousServer(model=model, p=q, clients=clients)
    server.timer.start()
    server._tick()
# -------------------------------------------------------------------------------------------------------
    # TRANSMITTED SIGNAL ESTIMATION

    x_pred = server.q.std_params
    x_pred2= server.q.std_params
    x_pred = x_pred['loc'][:M]
    x_pred = torch.where(x_pred< 0, -1, 1)
    err = (x_pred != x_o).sum().item() # perform element-wise comparison and count the number of True values
    errorr[count] = errorr[count] + err
  count = count + 1
errorr = errorr / (20*mc_iter)
print('error is:', errorr)
#np.save('/content/drive/MyDrive/Colab Notebooks/pvi-main/notebooks/examples/error_vector.npy', errorr)
# -------------------------------------------------------------------------------------------------------

# Plot SNR vs Bit-error

# plt.semilogy(snr, errorr)
# plt.xlabel('SNR (dB)')
# plt.ylabel('Bit error')
# plt.title('SNR vs. Bit-error')
# plt.grid(True)
# plt.show()
# ========================================================================================================





# Load the error vector from the .npy file
#loaded_error_vector = np.load('/content/drive/MyDrive/Colab Notebooks/pvi-main/notebooks/examples/error_vector.npy')

# Print the loaded vector
#print(loaded_error_vector)

print(x_pred)
print(x_o)
print(x_pred2)
c=x_o-x_pred
print(c)